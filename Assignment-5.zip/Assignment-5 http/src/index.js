var http = require("http");

const httpServer = http.createServer(handleServer);


function handleServer(req, res) {
  
    if(req.url === '/welcome'){
        res.setHeader("Content-Type","text/plain");
        res.statusCode= 200;
        res.end("Welcome to Dominos!");
        return;
    }else if(req.url === '/contact'){
        res.setHeader("Content-Type","application/json");
        res.statusCode= 200;
        res.end(
            JSON.stringify({
                phone: '18602100000', 
  	            email: 'guestcaredominos@jublfood.com'
            })
        );
        return;
    }else{
        res.statusCode = 404;
        res.end("Page not found")
        return;
    }
}

httpServer.listen(8081)
module.exports = httpServer;